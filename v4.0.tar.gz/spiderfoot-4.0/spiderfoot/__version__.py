VERSION = (4, 0, 0)

__version__ = '.'.join(map(str, VERSION))
