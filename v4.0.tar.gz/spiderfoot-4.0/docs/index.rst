.. spiderfoot documentation master file, created by
   sphinx-quickstart on Sat Jun 26 01:55:34 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to spiderfoot's documentation!
======================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   spiderfoot


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
